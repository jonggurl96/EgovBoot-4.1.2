CREATE VIEW comvnusermaster
			(esntl_id, user_id, password, user_nm, user_zip, user_adres, user_email, group_id, user_se, orgnzt_id) AS
SELECT comtngnrlmber.esntl_id,
       comtngnrlmber.mber_id          AS user_id,
       comtngnrlmber.password,
       comtngnrlmber.mber_nm          AS user_nm,
       comtngnrlmber.zip              AS user_zip,
       comtngnrlmber.adres            AS user_adres,
       comtngnrlmber.mber_email_adres AS user_email,
       ' '::bpchar                    AS group_id,
       'GNR'::text                    AS user_se,
       ' '::bpchar                    AS orgnzt_id
  FROM comtngnrlmber
 UNION ALL
SELECT comtnemplyrinfo.esntl_id,
       comtnemplyrinfo.emplyr_id   AS user_id,
       comtnemplyrinfo.password,
       comtnemplyrinfo.user_nm,
       comtnemplyrinfo.zip         AS user_zip,
       comtnemplyrinfo.house_adres AS user_adres,
       comtnemplyrinfo.email_adres AS user_email,
       comtnemplyrinfo.group_id,
       'USR'::text                 AS user_se,
       comtnemplyrinfo.orgnzt_id
  FROM comtnemplyrinfo
 UNION ALL
SELECT comtnentrprsmber.esntl_id,
       comtnentrprsmber.entrprs_mber_id       AS user_id,
       comtnentrprsmber.entrprs_mber_password AS password,
       comtnentrprsmber.cmpny_nm              AS user_nm,
       comtnentrprsmber.zip                   AS user_zip,
       comtnentrprsmber.adres                 AS user_adres,
       comtnentrprsmber.applcnt_email_adres   AS user_email,
       ' '::bpchar                            AS group_id,
       'ENT'::text                            AS user_se,
       ' '::bpchar                            AS orgnzt_id
  FROM comtnentrprsmber
 ORDER BY 1;

ALTER TABLE comvnusermaster
	OWNER TO postgres;

